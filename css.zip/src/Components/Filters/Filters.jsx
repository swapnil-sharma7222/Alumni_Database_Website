import React, { useState, useEffect, useReducer } from 'react';
import Select from 'react-select';
import { Link, useNavigate, useLocation } from "react-router-dom";
import { social } from '../Others/social_media';
import { options } from '../Filters/filter_queries'

const Filters = ({ post }) => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    navigate(`#page${currentPage}`);
  }, [currentPage, navigate]);

  const reducer= (filters, action)=> {
    console.log(action.type);
    switch (action.type) {
      case 'NEW':
        const newFilters= [...filters, action.payload];
        console.log("these are the new filters", newFilters);
        console.log("....");
        return newFilters;
        break;
      case 'RESET':
        console.log("Reset the filters", filters);
        sessionStorage.setItem('filters', JSON.stringify([]));
        return [];
        break;
    }
  }
  let filters= [];
  //const [filters, setFilters] = useState([]);
  // const [filters,dispatch]=useReducer(reducer,[]);
  const [filteredPosts, setFilteredPosts] = useState([]);
  const [value, setValue] = useState();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [postPerPage] = useState(100);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPassoutYears, setSelectedPassoutYears] = useState([]);
  const [batch, setBatch] = useState([]);
  const [selectedDepartment, setSelectedDepartment] = useState([]);
  const [selectedStates, setSelectedStates] = useState([]);
  const [selectedCity, setSelectedCity] = useState([]);
  const [selectedCompany, setSelectedCompany] = useState([]);
  const [selectedDegree, setSelectedDegree] = useState([]);
  const [selectedProgram, setSelectedProgram] = useState([]);
  const [selectedProfession, setSelectedProfession] = useState([]);
  const [selectedDesignation, setSelectedDesignation] = useState([]);
  
  

  const handleSubmit = () => {
    console.log("Hello from handleSubmit");
    console.log("These are the filters-->",filters);
    
    const flattened = filters.flat(Infinity);
    const filteredData = post.filter(item => {
      return flattened.some(flat => {
        return Object.values(item).includes(flat);
      });
    });
    setFilteredPosts((curr)=> {
      return filteredData;
    });
  }

  
  
  const uniqueBatchValues = [...new Set(post
    .filter(obj => obj.batch !== 'Nill')
    .map(obj => obj.batch)
  )];
  const uniqueDegreeValues = [...new Set(post
    .filter(obj => obj.degree && obj.degree !== 'Nill')
    .map((obj) => { return obj.degree[0]?.toUpperCase() + obj.degree.slice(1) })
  )];
  const uniqueProgramValues = [...new Set(post
    .filter(obj => obj.program && obj.program !== 'Nill')
    .map((obj) => { return obj.program[0]?.toUpperCase() + obj.program.slice(1) })
  )];
  const uniquePassoutyearValues = [...new Set(post
    .filter(obj => obj.passoutyear && obj.passoutyear !== 'Nill')
    .map((obj) => { return obj.passoutyear[0]?.toUpperCase() + obj.passoutyear.slice(1) })
  )];
  const uniqueDepartmentValues = [...new Set(post
    .filter(obj => obj.department && obj.department !== 'Nill')
    .map((obj) => { return obj.department[0]?.toUpperCase() + obj.department.slice(1) })
  )];
  const uniqueProfessionValues = [...new Set(post
    .filter(obj => obj.profession && obj.profession !== 'Nill')
    .map((obj) => { return obj.profession[0]?.toUpperCase() + obj.profession.slice(1) })
  )];
  const uniqueDesignationValues = [...new Set(post
    .filter(obj => obj.designation && obj.designation !== 'Nill')
    .map((obj) => { return obj.designation[0]?.toUpperCase() + obj.designation.slice(1) })
  )];
  const uniqueCompanyValues = [...new Set(post
    .filter(obj => obj.company && obj.company !== 'Nill')
    .map((obj) => { return obj.company[0]?.toUpperCase() + obj.company.slice(1) })
  )];
  const uniqueCityValues = [...new Set(post
    .filter(obj => obj.city && obj.city !== 'Nill')
    .map((obj) => { return obj.city[0]?.toUpperCase() + obj.city.slice(1) })
  )];
  const uniqueStateValues = [...new Set(post
    .filter(obj => obj.state && obj.state !== 'Nill')
    .map((obj) => { return obj.state[0]?.toUpperCase() + obj.state.slice(1) })
  )];

  const handleBatchFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newBatch = [...batch, selectedOptions]
    setBatch(newBatch);
  };
  const handleDegreeFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newDegree = [...selectedDegree, selectedOptions]
    setSelectedDegree(newDegree);
  };
  const handleProgramFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newProgram = [...selectedProgram, selectedOptions]
    setSelectedProgram(newProgram);
  };
  const handleCityFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newCity = [...selectedCity, selectedOptions]
    setSelectedCity(newCity);
  };
  const handlePassoutYearFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newPassoutYear = [...selectedPassoutYears, selectedOptions]
    setSelectedPassoutYears(newPassoutYear);
  };
  const handleDepartmentFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newDepartment = [...selectedDepartment, selectedOptions]
    setSelectedDepartment(newDepartment);
  };
  const handleProfessionFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newProfession = [...selectedProfession, selectedOptions]
    setSelectedProfession(newProfession);
  };
  const handleDesignationFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newDesignation = [...selectedDesignation, selectedOptions]
    setSelectedDesignation(newDesignation);
  };
  const handleStateFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newState = [...selectedStates, selectedOptions]
    setSelectedStates(newState);
  };
  const handleCompanyFilter = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, (option) => option.value);
    const newCompany = [...selectedCompany, selectedOptions]
    setSelectedCompany(newCompany);
  };

  const lastPostNumber = postPerPage * currentPage;
  const firstPostNumber = (postPerPage * currentPage) - postPerPage;
  const currentPosts = filteredPosts.length ? filteredPosts.slice(firstPostNumber, lastPostNumber) : post.slice(firstPostNumber, lastPostNumber);
  const totalPages = filteredPosts.length ? Math.ceil(filteredPosts.length / postPerPage) : Math.ceil(post.length / postPerPage);

  const renderSelect = (label, options) => (
    <label key={label}>
      {label}
      {/* <input list= {options}/> */}
      <Select
        id={options}
        onChange={handleChange}
        options={options.map((option, i) => ({ value: option, label: option }))}
        placeholder={`Select ${label}`}
        isSearchable={false}
      />
    </label>
  );

  const handleChange = (e, selectedOption) => {
    console.log(e);
    console.log(selectedOption);
    const selectedValue = selectedOption ? selectedOption.value : ""; 
    // const newBatch = [...filters, selectedValue];
    // sessionStorage.setItem('filters', JSON.stringify(newBatch));
    // dispatch({type: 'NEW', payload: newBatch});
    filters = [...filters, selectedValue];
    console.log(filters.length);
    sessionStorage.setItem('filters', JSON.stringify(filters));
    console.log("these are the new selections", filters);
  };

  useEffect(()=> {
    const storedFilters= sessionStorage.getItem("filters");
    const parseFilters= JSON.parse(storedFilters);
    console.log(`my filters ${parseFilters}`);

    if(parseFilters){
      console.log("These are parsed filters",parseFilters);
      // dispatch({type: 'NEW', payload: parseFilters});
      filters = [...filters, parseFilters];
      console.log("session storage-->",filters);
      handleSubmit();
    }
    // handleSubmit();
  }, []);


  return (
    
    <div>
      <div className='sidebar-header' style={{ textAlign: 'center' }}>
        <h2>Filters</h2>
        <button onClick={handleSubmit}>Apply</button>
        <button onClick={() => {
            // dispatch({type: 'RESET', payload: []});
            filters= [];
            setFilteredPosts([]) 
          }}
          >Reset</button>
      </div>
      <div>
        <input type="text" placeholder='Enter a filter' />
        <div>
          {filters.length? filters.map((filter, index)=> {
            <div key= {index}>
              {filter}
            </div>
          }): <h2>{filters.length}</h2>}
          {/* <h1></h1> */}
        </div>
      </div>
      {/* List of Filters */}
      <ul className='links'>
        <div>
          {renderSelect("Batch", uniqueBatchValues)}
          {renderSelect("Degree", uniqueDegreeValues)}
          {renderSelect("Program", uniqueProgramValues)}
          {renderSelect("Passout Year", uniquePassoutyearValues)}
          {renderSelect("Department", uniqueDepartmentValues)}
          {renderSelect("Profession", uniqueProfessionValues)}
          {renderSelect("Designation", uniqueDesignationValues)}
          {renderSelect("Company", uniqueCompanyValues)}
          {renderSelect("City", uniqueCityValues)}
          {renderSelect("State", uniqueStateValues)}
        </div>
      </ul>
      <div>
        {currentPosts.map((post, index) => {
          return (
            <Link to={`${post._id}`} post={post}>
              <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', border: '1px solid black' }} key={index}>
                <p>{(currentPage - 1) * postPerPage + index + 1}</p>
                <p>
                  {post.name === 'Nill' ? '-' : post.name}
                </p>
                <p>
                  {post.batch === 'Nill' ? '-' : post.batch}
                </p>
                <p>
                  {post.department === 'Nill' ? '-' : post.department}
                </p>
              </div>
            </Link>
          )
        })}
      </div>

      {/* Pagination Buttons */}
      <div>
        <button onClick={() => {
          setCurrentPage((curr) => {
            let prevPage = curr - 1;
            if (prevPage <= 0) {
              prevPage = totalPages;
            }
            return prevPage;
          })
        }}>Prev</button>
        {Array.from({ length: 7 }, (_, index) => {
          let pageNumber = currentPage + index;
          if (pageNumber > totalPages) {
            return null;
          }
          if (pageNumber <= 0) {
            pageNumber = totalPages + pageNumber;
          }
          return (
            <button
              key={pageNumber}
              onClick={() => setCurrentPage(pageNumber)}
            >
              {pageNumber}
            </button>
          )
        })}
        <button onClick={() => {
          setCurrentPage((curr) => {
            let nextPage = Number(curr) + 1;
            if (nextPage > totalPages) {
              nextPage = 1;
            }
            return nextPage;
          })
        }}>Next</button>
      </div>

    </div >
  );
};

export default Filters;
